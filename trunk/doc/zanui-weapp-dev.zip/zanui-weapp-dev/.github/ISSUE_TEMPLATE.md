### 请认真写 ISSUE 的标题，会用于生成 change log。

**请确认是需要 *新增功能* 还是 *提交bug* **

** 如果是 bug，请提供复现步骤，可能的话，可以在 [https://jsfiddle.net](https://jsfiddle.net) 或者类似平台上提供一个 demo **
