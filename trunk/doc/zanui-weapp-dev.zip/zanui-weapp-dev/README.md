<p>
<a href="https://github.com/youzan/"><img alt="有赞logo" width="36px" src="https://img.yzcdn.cn/public_files/2017/02/09/e84aa8cbbf7852688c86218c1f3bbf17.png" alt="youzan">
</p></a>
<p align="center">
    <img alt="项目logo" src="https://img.yzcdn.cn/public_files/2017/02/06/ee0ebced79a80457d77ce71c7d414c74.png">
</p>
<p align="center">高颜值、好用、易扩展的小程序 UI 库</p>

## 升级及更名提示

ZanUI-WeApp 现已升级为 [Vant Weapp](https://github.com/youzan/vant-weapp)，Vant Weapp 是有赞移动端组件库 Vant 的小程序版本，两者基于相同的视觉规范，提供一致的 API 接口，助力开发者快速搭建小程序应用。

本仓库后续进入维护状态，不会再有大的版本更新。建议用户逐渐迁移至 Vant Weapp.

Vant Weapp 仓库地址: [https://github.com/youzan/vant-weapp](https://github.com/youzan/vant-weapp)
