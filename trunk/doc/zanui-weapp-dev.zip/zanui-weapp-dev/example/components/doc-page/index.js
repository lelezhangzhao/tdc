Component({
  properties: {
    title: {
      type: String,
      value: ''
    },

    withoutPadding: {
      type: Boolean
    }
  }
});
