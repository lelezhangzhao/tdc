import componentsConfig from './config';

Page({
  data: {
    list: componentsConfig
  },

  onLoad: function () {

  },

  onShow: function() {
  },
})
