module.exports = {
  pro1Name: '浙江',
  pro1: [{
    text: '杭州',
    id: 1001
  }, {
    text: '温州',
    id: 1002
  }, {
    text: '宁波',
    id: 1003
  }, {
    text: '义乌',
    id: 1004
  }],
  pro2Name: '江苏',
  pro2: [{
    text: '无锡',
    id: 1011
  }, {
    text: '常州',
    id: 1012
  }, {
    text: '莆田',
    id: 1013
  }, {
    text: '三明',
    id: 1014
  }]
};
