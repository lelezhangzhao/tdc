Page({
  data: {
    bar1: {
      text: '足协杯战线连续第2年上演广州德比战，上赛季半决赛上恒大以两回合5-3的总比分淘汰富力。',
      scrollable: true,
      delay: 1000
    },
    bar2: {
      text: '足协杯战线连续第2年上演广州德比战',
      color: '#fff',
      backgroundColor: '#000'
    },
    bar3: {
      text: '足协杯战线连续第2年上演广州德比战，上赛季半决赛上恒大以两回合5-3的总比分淘汰富力。'
    },
    bar4: {
      text: '带icon的公告',
      leftIcon: 'https://img.yzcdn.cn/public_files/2017/8/10/6af5b7168eed548100d9041f07b7c616.png'
    },
    bar5: {
      text: '足协杯战线连续第2年上演广州德比战，上赛季半决赛上恒大以两回合5-3的总比分淘汰富力。',
      leftIcon: 'https://img.yzcdn.cn/public_files/2017/8/10/6af5b7168eed548100d9041f07b7c616.png',
      mode: 'closeable',
      scrollable: true,
      speed: 10
    }
  }
})
