Page({
  data: {
  },

  onLoad() {

  },

  onShow() {
  },

  getPhoneNumber(e) {
    console.log(e);
  }
});
