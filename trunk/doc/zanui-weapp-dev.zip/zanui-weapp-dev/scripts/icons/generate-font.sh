#!/bin/sh

basepath=$(dirname $0)

iconfount --config $basepath/fount-config.js
