cd website && yarn && yarn cache node_modules

npm run build

cd ../


