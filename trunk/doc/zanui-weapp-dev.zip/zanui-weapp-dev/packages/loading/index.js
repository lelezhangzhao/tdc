Component({
  properties: {
    type: {
      type: String,
      value: 'circle'
    },
    color: {
      type: String
    }
  }
});
