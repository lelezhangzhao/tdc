Component({
  properties: {
    type: {
      type: String,
      value: 'loading'
    },
    text: {
      type: String,
      value: ''
    }
  }
});
