App({
    globalData: {

    },
});