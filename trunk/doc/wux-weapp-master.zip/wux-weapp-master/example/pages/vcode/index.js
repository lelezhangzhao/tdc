Page({
    data: {},
    onLoad() {},
    onChange(e) {
        console.log(`验证码：${e.detail.value}`)
    },
})