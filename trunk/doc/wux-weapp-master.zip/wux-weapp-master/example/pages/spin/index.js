Page({
    onClick(e) {
        this.setData({
            spinning: !this.data.spinning,
        })
    },
})