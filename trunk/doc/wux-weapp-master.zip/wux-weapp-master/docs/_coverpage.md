![logo](_images/logo.png)

# Wux Weapp <small>3.1.0</small>

<p align="center">
    <a href="https://github.com/wux-weapp/wux-weapp/" target="_blank">
    	<img alt="star this repo" src="http://githubbadges.com/star.svg?user=wux-weapp&repo=wux-weapp&style=flat" />
    </a>
	<a href="https://github.com/wux-weapp/wux-weapp/fork" target="_blank">
		<img alt="fork this repo" src="http://githubbadges.com/fork.svg?user=wux-weapp&repo=wux-weapp&style=flat" />
	</a>
	<a href="https://www.npmjs.com/package/wux-weapp" target="_blank">
    	<img src='https://img.shields.io/npm/v/wux-weapp.svg' />
    </a>
    <br />
	<a href="https://www.npmjs.com/package/wux-weapp" target="_blank">
		<img src="https://img.shields.io/npm/dm/wux-weapp.svg?style=flat" />
	</a>
	<a href="https://www.npmjs.com/package/wux-weapp" target="_blank">
		<img src="https://img.shields.io/npm/dt/wux-weapp.svg?style=flat" />
	</a>
	<a href="https://www.npmjs.com/package/wux-weapp" target="_blank">
		<img src="https://img.shields.io/npm/l/wux-weapp.svg?style=flat" />
	</a>
</p>

> 微信小程序自定义 UI 组件

* 组件化、可复用、易扩展

[GitHub](https://github.com/wux-weapp/wux-weapp/)
[Get Started](quickstart)
